@rem Visual C++ ���������ű�
@rem �������ű��������Ǳ�д����ӭ����

@echo off
echo -------------------------------------------------------
echo **    �����ű� Ver 0.1        
echo **                                                                     
echo **     ����: ������                                            
echo **
echo -------------------------------------------------------

cd /d %~dp0 

del /S *.obj 
del /S *.ilk 
del /S *.pdb 
del /S *.plg 
del /S *.bsc 

del /S *.trc 
del /S *.pch 
del /S *.idb 
del /S *.exp 
del /S *.sbr 
rem  del /S *.res       rem ����ɾ��c#�� *.resx�ļ�
del /S *.ncb
del /S *.opt
del /S *.SUP
del /S *.aps

del /S *.suo
rem del /S *.manifest   VS2013��Ҫ���ļ�
del /S *.dep
del /S *.sdf
del /S *.tlog
del /S *.log
del /S *.ipch
del /S *.lastbuildstate
rem del /S *.htm
del /S *.user


del /S *.bak
del /S *.o
del /S *.db

del /S /Q *.iobj
del /S /Q *.ipdb
del /S /Q *.recipe

rem ɾ����Ŀ¼��  .vs
set "targetDirectory=.vs" 

for /d /r %%D in (*) do (
    if exist "%%D\%targetDirectory%" (
        echo Deleting "%%D\%targetDirectory%"...
        rd /s /q "%%D\%targetDirectory%"
        echo Subdirectory deleted successfully.
    )
)

set "targetDirectory=ipch" 
for /d /r %%D in (*) do (
    if exist "%%D\%targetDirectory%" (
        echo Deleting "%%D\%targetDirectory%"...
        rd /s /q "%%D\%targetDirectory%"
        echo Subdirectory deleted successfully.
    )
)

@echo off

